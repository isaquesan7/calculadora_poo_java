
package calculadorafinal;

public abstract class C_abs_class{
    
    public abstract void Porcentagem(String numero);
}
