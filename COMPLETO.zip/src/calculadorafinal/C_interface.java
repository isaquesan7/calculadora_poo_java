
package calculadorafinal;

public interface C_interface {
    
    void Soma(String numero);
    void Subtracao(String numero);
    void Multiplicacao(String numero);
    void Divisao(String numero);
    
}
